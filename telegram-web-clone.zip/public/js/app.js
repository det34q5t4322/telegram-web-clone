// Telegram Web Client Application Logic

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const appContainer = document.querySelector('.app-container');
  const profileModal = document.getElementById('profile-modal');
  const usernameInput = document.getElementById('username-input');
  const saveProfileBtn = document.getElementById('save-profile-btn');
  const avatarFileInput = document.getElementById('avatar-file');
  const modalAvatarPreview = document.getElementById('modal-avatar-preview');

  const myAvatarEl = document.getElementById('my-avatar');
  const myUsernameEl = document.getElementById('my-username');

  const chatsListEl = document.getElementById('chats-list');
  const messagesContainer = document.getElementById('messages-container');
  const messageInput = document.getElementById('message-input');
  const sendBtn = document.getElementById('send-btn');
  const voiceBtn = document.getElementById('voice-btn');
  const attachBtn = document.getElementById('attach-btn');
  const fileInput = document.getElementById('file-input');

  const voiceRecordingUI = document.getElementById('voice-recording-ui');
  const voiceTimerEl = document.getElementById('voice-timer');
  const cancelVoiceBtn = document.getElementById('cancel-voice-btn');

  const emojiPickerBtn = document.getElementById('emoji-picker-btn');
  const emojiPopup = document.getElementById('emoji-popup');
  const stickersGrid = document.getElementById('stickers-grid');
  const gifsGrid = document.getElementById('gifs-grid');

  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  const shareLinkBtn = document.getElementById('share-link-btn');
  const headerShareBtn = document.getElementById('header-share-btn');
  const shareModal = document.getElementById('share-modal');
  const closeShareModal = document.getElementById('close-share-modal');
  const shareUrlInput = document.getElementById('share-url-input');
  const copyShareBtn = document.getElementById('copy-share-btn');
  const passcodeBox = document.getElementById('passcode-box');
  const passcodeVal = document.getElementById('passcode-val');

  const replyBanner = document.getElementById('reply-banner');
  const replyUserEl = document.getElementById('reply-user');
  const replyTextEl = document.getElementById('reply-text');
  const cancelReplyBtn = document.getElementById('cancel-reply-btn');

  const pinnedBanner = document.getElementById('pinned-banner');
  const pinnedSnippet = document.getElementById('pinned-snippet');
  const pinnedContentBtn = document.getElementById('pinned-content-btn');
  const unpinBtn = document.getElementById('unpin-btn');

  const pollBtn = document.getElementById('poll-btn');
  const pollModal = document.getElementById('poll-modal');
  const pollQuestionInput = document.getElementById('poll-question-input');
  const submitPollBtn = document.getElementById('submit-poll-btn');
  const cancelPollBtn = document.getElementById('cancel-poll-btn');

  const btnAudioCall = document.getElementById('btn-audio-call');
  const btnVideoCall = document.getElementById('btn-video-call');
  const callModal = document.getElementById('call-modal');
  const callUsername = document.getElementById('call-username');
  const callStatus = document.getElementById('call-status');
  const callEndBtn = document.getElementById('call-end-btn');

  const btnWallpaperModal = document.getElementById('btn-wallpaper-modal');
  const wallpaperModal = document.getElementById('wallpaper-modal');
  const closeWallpaperModal = document.getElementById('close-wallpaper-modal');
  const chatWallpaperTarget = document.getElementById('chat-wallpaper-target');

  const btnInchatSearch = document.getElementById('btn-inchat-search');
  const inchatSearchBar = document.getElementById('inchat-search-bar');
  const inchatSearchInput = document.getElementById('inchat-search-input');
  const closeInchatSearch = document.getElementById('close-inchat-search');

  const typingIndicator = document.getElementById('typing-indicator');
  const typingTextEl = document.getElementById('typing-text');

  const lightboxModal = document.getElementById('lightbox-modal');
  const lightboxImg = document.getElementById('lightbox-img');
  const closeLightbox = document.getElementById('close-lightbox');

  const activeChatTitle = document.getElementById('active-chat-title');
  const activeChatSubtitle = document.getElementById('active-chat-subtitle');

  // State Variables
  let socket = null;
  let currentUser = null;
  let currentRoomId = 'general';
  let activeReplyMsg = null;
  let currentPinnedMsg = null;
  let typingTimeout = null;
  let mediaRecorder = null;
  let audioChunks = [];
  let recordingInterval = null;
  let recordSeconds = 0;

  const avatarColors = ['bg-blue', 'bg-green', 'bg-orange', 'bg-purple', 'bg-red'];

  const stickerPack = [
    { id: 'duck_hi', url: 'https://cdn.jsdelivr.net/gh/TelegramMessenger/TWeb@master/src/assets/img/duck/duck_hi.png' },
    { id: 'duck_love', url: 'https://cdn.jsdelivr.net/gh/TelegramMessenger/TWeb@master/src/assets/img/duck/duck_love.png' },
    { id: 'duck_cool', url: 'https://cdn.jsdelivr.net/gh/TelegramMessenger/TWeb@master/src/assets/img/duck/duck_cool.png' },
    { id: 'duck_dance', url: 'https://cdn.jsdelivr.net/gh/TelegramMessenger/TWeb@master/src/assets/img/duck/duck_dance.png' },
    { id: 'pepe_happy', url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3hxdTJ3MnNyc280dWFwdnBva3dzd3FyejdpdDdxbm5uNGkydXpydSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/eoxomXXVL2S0E/giphy.gif' },
    { id: 'pepe_fire', url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbnE3eGFkNDFsaTZuZ3NpdHlsaG1xdHJybHBnZDRwYnJ1ZjFmMGd3aiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/l0HlHJGHe3yAMhdQY/giphy.gif' },
    { id: 'cat_vibe', url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNGQxbnpzaWs5NWtqdXBvaXdzbnZzNWRxNnF4czY4c2tzanFxd3lzOCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/jpbnoe3UIa8TU8LM13/giphy.gif' },
    { id: 'cat_pop', url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNGhscHFlbnZ3NWYzaDRnNzBqdThreDF0Zjdjcm94azlnNHB1OGlpaSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/K1tgb1IUeBOQw/giphy.gif' },
    { id: 'doge_wow', url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExd245OWlkaGtrbmRka2c3Nm0xNDhxejh4dWRyZnlydXdydmVhNXdwaCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/51u38TGfZMGS5x8Mlh/giphy.gif' }
  ];

  const gifPack = [
    { url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNDNqM285Z2VxcWs2amIxb2oxbmE2c2s4cDVvdzhxcHFvN2I1bDRuZSZlcD12MV_pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l3vR4CdLInEAhergI/giphy.gif' },
    { url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Z6cW9vMmEwdnpsNWtrcTl1b2NqbmNvcWdpNmY4NW9iaDF0ZHRzYiZlcD12MV_pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/13CoXDiaCcCoyk/giphy.gif' },
    { url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYzJmNXdwdXNodDFpaTh2bjFlZ3NreGkwaHZuc3lra3A2Ymk4b2VmdSZlcD12MV_pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l0AMJLnn71j85hOAE/giphy.gif' },
    { url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYnJ2OXl0OWwxb2s4NXFtdXg4eTFsNDI2YnFwbXBsYTRiOTNveHlhdyZlcD12MV_pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o7TKSjRrfIPjeiVyM/giphy.gif' }
  ];

  const urlParams = new URLSearchParams(window.location.search);
  const roomParam = urlParams.get('chat');
  if (roomParam) {
    currentRoomId = roomParam;
  }

  function initUserSession() {
    const savedUser = localStorage.getItem('tg_user');
    if (savedUser) {
      currentUser = JSON.parse(savedUser);
      profileModal.classList.add('hidden');
      updateUserProfileUI();
      connectSocket();
    } else {
      profileModal.classList.remove('hidden');
    }
  }

  function updateUserProfileUI() {
    if (!currentUser) return;
    myUsernameEl.textContent = currentUser.username;
    
    if (currentUser.avatar && currentUser.avatar.startsWith('http')) {
      myAvatarEl.style.backgroundImage = `url(${currentUser.avatar})`;
      myAvatarEl.textContent = '';
    } else {
      myAvatarEl.style.backgroundImage = '';
      myAvatarEl.textContent = currentUser.username.charAt(0).toUpperCase();
      myAvatarEl.className = `avatar ${currentUser.colorClass || 'bg-blue'}`;
    }
  }

  let uploadedAvatarUrl = null;
  avatarFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Bypass-Tunnel-Reminder': 'true' },
        body: formData
      });
      const data = await res.json();
      if (data.fileUrl) {
        uploadedAvatarUrl = data.fileUrl;
        modalAvatarPreview.style.backgroundImage = `url(${uploadedAvatarUrl})`;
        modalAvatarPreview.textContent = '';
      }
    } catch (err) {
      console.error('Avatar upload error:', err);
    }
  });

  saveProfileBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    if (!username) {
      alert('Пожалуйста, введите ваше имя!');
      return;
    }

    const randomColor = avatarColors[Math.floor(Math.random() * avatarColors.length)];
    currentUser = {
      id: 'usr_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      username: username,
      avatar: uploadedAvatarUrl || null,
      colorClass: randomColor
    };

    localStorage.setItem('tg_user', JSON.stringify(currentUser));
    profileModal.classList.add('hidden');
    updateUserProfileUI();
    connectSocket();
  });

  function connectSocket() {
    // Configure socket.io to bypass localtunnel reminder page
    socket = io({
      extraHeaders: {
        'Bypass-Tunnel-Reminder': 'true'
      }
    });

    socket.on('connect', () => {
      console.log('Connected to server');
      socket.emit('user:join', currentUser);

      if (currentRoomId !== 'general') {
        socket.emit('room:join', { roomId: currentRoomId, roomName: 'Приватный чат' });
        activeChatTitle.textContent = currentRoomId === 'ai_bot' ? '🤖 Telegram AI Bot' : (currentRoomId === 'saved_messages' ? '🔖 Избранное' : 'Приватный чат');
      }
    });

    socket.on('chat:history', ({ roomId, messages, pinned }) => {
      messagesContainer.innerHTML = '<div class="date-divider"><span>История сообщений</span></div>';
      messages.forEach(msg => renderMessage(msg));
      updatePinnedBannerUI(pinned);
      scrollToBottom();
    });

    socket.on('message:new', (msg) => {
      renderMessage(msg);
      scrollToBottom();
      if (msg.senderId !== currentUser.id) {
        playNotificationSound();
      }
    });

    socket.on('message:updated', (msg) => {
      const existingEl = document.querySelector(`[data-msg-id="${msg.id}"]`);
      if (existingEl) {
        updateMessageReactionsAndPollUI(existingEl, msg);
      }
    });

    socket.on('chat:pinned_update', ({ roomId, pinned }) => {
      if (roomId === currentRoomId) {
        updatePinnedBannerUI(pinned);
      }
    });

    socket.on('message:deleted', ({ messageId }) => {
      const existingEl = document.querySelector(`[data-msg-id="${messageId}"]`);
      if (existingEl) {
        existingEl.remove();
      }
    });

    socket.on('typing:status', ({ userId, username, isTyping }) => {
      if (userId === currentUser.id) return;
      if (isTyping) {
        typingTextEl.textContent = `${username} печатает...`;
        typingIndicator.classList.remove('hidden');
      } else {
        typingIndicator.classList.add('hidden');
      }
    });

    socket.on('call:incoming', ({ callerName, callerAvatar, isVideo }) => {
      callUsername.textContent = callerName;
      callStatus.textContent = isVideo ? 'Входящий видеовызов...' : 'Входящий аудиовызов...';
      callModal.classList.remove('hidden');
    });
  }

  document.querySelectorAll('.chat-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.chat-item').forEach(ci => ci.classList.remove('active'));
      item.classList.add('active');

      const roomId = item.getAttribute('data-room-id');
      const roomName = item.getAttribute('data-room-name');
      currentRoomId = roomId;
      activeChatTitle.textContent = roomName;

      if (socket) {
        socket.emit('room:join', { roomId, roomName });
      }
    });
  });

  function updatePinnedBannerUI(pinnedMsg) {
    currentPinnedMsg = pinnedMsg;
    if (pinnedMsg) {
      pinnedSnippet.textContent = pinnedMsg.text || 'Медиафайл';
      pinnedBanner.classList.remove('hidden');
    } else {
      pinnedBanner.classList.add('hidden');
    }
  }

  pinnedContentBtn.addEventListener('click', () => {
    if (currentPinnedMsg) {
      const targetEl = document.querySelector(`[data-msg-id="${currentPinnedMsg.id}"]`);
      if (targetEl) {
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        targetEl.style.transition = 'background 0.5s';
        targetEl.style.background = 'var(--accent-light)';
        setTimeout(() => targetEl.style.background = '', 1500);
      }
    }
  });

  unpinBtn.addEventListener('click', () => {
    if (socket) {
      socket.emit('message:pin', { roomId: currentRoomId, messageId: null });
    }
  });

  function renderMessage(msg) {
    const isOutgoing = msg.senderId === currentUser.id;
    const isSticker = msg.type === 'sticker';
    const isGif = msg.type === 'gif';
    const isPoll = msg.type === 'poll';

    const msgWrapper = document.createElement('div');
    msgWrapper.className = `msg-wrapper ${isOutgoing ? 'outgoing' : 'incoming'} ${isSticker ? 'sticker-msg' : ''}`;
    msgWrapper.setAttribute('data-msg-id', msg.id);

    const formattedTime = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let replyHtml = '';
    if (msg.replyTo) {
      replyHtml = `
        <div class="msg-reply-context">
          <span class="msg-reply-user">${escapeHtml(msg.replyTo.senderName)}</span>
          <span class="msg-reply-snippet">${escapeHtml(msg.replyTo.text || 'Медиафайл')}</span>
        </div>
      `;
    }

    let bodyHtml = '';
    if (isPoll && msg.pollData) {
      bodyHtml = renderPollHtml(msg);
    } else if (isSticker) {
      bodyHtml = `<img src="${msg.fileUrl}" class="msg-sticker-img" alt="Sticker">`;
    } else if (isGif) {
      bodyHtml = `<img src="${msg.fileUrl}" class="msg-gif-img" alt="GIF">`;
    } else if (msg.type === 'image' || msg.fileUrl && isImageFile(msg.fileName)) {
      bodyHtml = `
        ${msg.text ? `<div class="msg-text">${escapeHtml(msg.text)}</div>` : ''}
        <img src="${msg.fileUrl}" class="msg-image" alt="Attachment" onclick="openLightbox('${msg.fileUrl}')">
      `;
    } else if (msg.type === 'voice') {
      bodyHtml = `
        <div class="voice-player">
          <button class="voice-play-btn" onclick="toggleVoicePlay(this, '${msg.fileUrl}')">
            <i class="fa-solid fa-play"></i>
          </button>
          <span class="speed-badge" onclick="cycleVoiceSpeed(this)">1.0x</span>
          <div class="voice-waveform">
            ${generateWaveformBars()}
          </div>
        </div>
      `;
    } else if (msg.fileUrl) {
      bodyHtml = `
        <div class="msg-text">
          <a href="${msg.fileUrl}" target="_blank" style="color: var(--accent-color); text-decoration: underline;">
            <i class="fa-solid fa-file-arrow-down"></i> ${escapeHtml(msg.fileName || 'Скачать файл')}
          </a>
        </div>
      `;
    } else {
      bodyHtml = `<div class="msg-text">${escapeHtml(msg.text)}</div>`;
    }

    msgWrapper.innerHTML = `
      <div class="msg-actions-bar">
        <button class="icon-btn" onclick="triggerReaction('${msg.id}', '👍')">👍</button>
        <button class="icon-btn" onclick="triggerReaction('${msg.id}', '❤️')">❤️</button>
        <button class="icon-btn" onclick="triggerReaction('${msg.id}', '😂')">😂</button>
        <button class="icon-btn" title="Закрепить" onclick="pinMsg('${msg.id}')"><i class="fa-solid fa-thumbtack"></i></button>
        <button class="icon-btn" title="Ответить" onclick="triggerReply('${msg.id}', '${escapeHtml(msg.senderName)}', '${escapeHtml(msg.text || 'Медиа')}')">
          <i class="fa-solid fa-reply"></i>
        </button>
        ${isOutgoing ? `<button class="icon-btn text-danger" onclick="deleteMsg('${msg.id}')"><i class="fa-solid fa-trash"></i></button>` : ''}
      </div>

      <div class="msg-bubble">
        ${!isOutgoing && !isSticker ? `<div class="msg-sender">${escapeHtml(msg.senderName)}</div>` : ''}
        ${replyHtml}
        ${bodyHtml}
        <div class="msg-reactions" id="reactions-${msg.id}"></div>
        <div class="msg-meta">
          <span>${formattedTime}</span>
          ${isOutgoing ? '<i class="fa-solid fa-check-double check-icon"></i>' : ''}
        </div>
      </div>
    `;

    messagesContainer.appendChild(msgWrapper);
    updateMessageReactionsAndPollUI(msgWrapper, msg);
  }

  function renderPollHtml(msg) {
    const poll = msg.pollData;
    let totalVotes = 0;
    poll.options.forEach(opt => totalVotes += (opt.votes ? opt.votes.length : 0));

    let optionsHtml = '';
    poll.options.forEach((opt, idx) => {
      const voteCount = opt.votes ? opt.votes.length : 0;
      const pct = totalVotes > 0 ? Math.round((voteCount / totalVotes) * 100) : 0;
      const hasVoted = opt.votes && opt.votes.includes(currentUser.id);

      optionsHtml += `
        <div class="poll-option-item ${hasVoted ? 'voted' : ''}" onclick="votePoll('${msg.id}', ${idx})">
          <div class="poll-option-fill" style="width: ${pct}%"></div>
          <span class="poll-option-text">${escapeHtml(opt.text)}</span>
          <span class="poll-option-pct">${pct}%</span>
        </div>
      `;
    });

    return `
      <div class="poll-container">
        <div class="poll-question">📊 ${escapeHtml(poll.question)}</div>
        ${optionsHtml}
        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 4px;">Проголосовало: ${totalVotes}</div>
      </div>
    `;
  }

  function updateMessageReactionsAndPollUI(msgElement, msg) {
    const reactionsContainer = msgElement.querySelector('.msg-reactions');
    if (reactionsContainer) {
      reactionsContainer.innerHTML = '';
      if (msg.reactions) {
        Object.keys(msg.reactions).forEach(emoji => {
          const userIds = msg.reactions[emoji];
          if (userIds.length > 0) {
            const pill = document.createElement('span');
            pill.className = `reaction-pill ${userIds.includes(currentUser.id) ? 'active' : ''}`;
            pill.innerHTML = `${emoji} <span>${userIds.length}</span>`;
            pill.onclick = () => triggerReaction(msg.id, emoji);
            reactionsContainer.appendChild(pill);
          }
        });
      }
    }

    if (msg.type === 'poll') {
      const bubble = msgElement.querySelector('.msg-bubble');
      if (bubble) {
        const sender = bubble.querySelector('.msg-sender');
        const meta = bubble.querySelector('.msg-meta');
        bubble.innerHTML = `${sender ? sender.outerHTML : ''}${renderPollHtml(msg)}<div class="msg-reactions"></div>${meta.outerHTML}`;
      }
    }
  }

  function generateWaveformBars() {
    let bars = '';
    for (let i = 0; i < 28; i++) {
      const height = Math.floor(Math.random() * 16) + 6;
      bars += `<div class="wave-bar" style="height: ${height}px"></div>`;
    }
    return bars;
  }

  window.votePoll = (messageId, optionIdx) => {
    if (socket) {
      socket.emit('poll:vote', { messageId, optionIdx });
    }
  };

  window.pinMsg = (messageId) => {
    if (socket) {
      socket.emit('message:pin', { roomId: currentRoomId, messageId });
    }
  };

  window.triggerReaction = (messageId, emoji) => {
    if (socket) {
      socket.emit('message:react', { messageId, emoji });
    }
  };

  window.triggerReply = (messageId, senderName, text) => {
    activeReplyMsg = { id: messageId, senderName, text };
    replyUserEl.textContent = senderName;
    replyTextEl.textContent = text;
    replyBanner.classList.remove('hidden');
    messageInput.focus();
  };

  window.deleteMsg = (messageId) => {
    if (confirm('Удалить это сообщение для всех?') && socket) {
      socket.emit('message:delete', { messageId });
    }
  };

  window.openLightbox = (url) => {
    lightboxImg.src = url;
    lightboxModal.classList.remove('hidden');
  };

  closeLightbox.addEventListener('click', () => {
    lightboxModal.classList.add('hidden');
  });

  cancelReplyBtn.addEventListener('click', () => {
    activeReplyMsg = null;
    replyBanner.classList.add('hidden');
  });

  let activeAudio = null;
  let currentSpeed = 1.0;
  window.toggleVoicePlay = (btn, url) => {
    if (activeAudio && !activeAudio.paused) {
      activeAudio.pause();
      btn.innerHTML = '<i class="fa-solid fa-play"></i>';
      if (activeAudio.src.includes(url)) return;
    }

    activeAudio = new Audio(url);
    activeAudio.playbackRate = currentSpeed;
    btn.innerHTML = '<i class="fa-solid fa-pause"></i>';
    activeAudio.play();

    activeAudio.onended = () => {
      btn.innerHTML = '<i class="fa-solid fa-play"></i>';
    };
  };

  window.cycleVoiceSpeed = (badge) => {
    if (currentSpeed === 1.0) currentSpeed = 1.5;
    else if (currentSpeed === 1.5) currentSpeed = 2.0;
    else currentSpeed = 1.0;

    badge.textContent = `${currentSpeed.toFixed(1)}x`;
    if (activeAudio) activeAudio.playbackRate = currentSpeed;
  };

  pollBtn.addEventListener('click', () => pollModal.classList.remove('hidden'));
  cancelPollBtn.addEventListener('click', () => pollModal.classList.add('hidden'));

  submitPollBtn.addEventListener('click', () => {
    const question = pollQuestionInput.value.trim();
    if (!question) {
      alert('Введите вопрос опроса!');
      return;
    }

    const optionInputs = document.querySelectorAll('.poll-option-input');
    const options = [];
    optionInputs.forEach(opt => {
      const val = opt.value.trim();
      if (val) options.push({ text: val, votes: [] });
    });

    if (options.length < 2) {
      alert('Заполните минимум 2 варианта ответа!');
      return;
    }

    if (socket) {
      socket.emit('message:send', {
        roomId: currentRoomId,
        type: 'poll',
        pollData: { question, options }
      });
    }

    pollQuestionInput.value = '';
    optionInputs.forEach(o => o.value = '');
    pollModal.classList.add('hidden');
  });

  btnAudioCall.addEventListener('click', () => triggerCall(false));
  btnVideoCall.addEventListener('click', () => triggerCall(true));

  function triggerCall(isVideo) {
    callUsername.textContent = activeChatTitle.textContent;
    callStatus.textContent = isVideo ? 'Исходящий видеовызов...' : 'Исходящий аудиовызов...';
    callModal.classList.remove('hidden');

    if (socket) {
      socket.emit('call:initiate', { isVideo });
    }
  }

  callEndBtn.addEventListener('click', () => {
    callModal.classList.add('hidden');
    if (socket) socket.emit('call:end');
  });

  btnWallpaperModal.addEventListener('click', () => wallpaperModal.classList.remove('hidden'));
  closeWallpaperModal.addEventListener('click', () => wallpaperModal.classList.add('hidden'));

  document.querySelectorAll('.wp-item').forEach(item => {
    item.addEventListener('click', () => {
      const wp = item.getAttribute('data-wp');
      chatWallpaperTarget.className = `chat-area ${wp !== 'default' ? 'wp-' + wp : ''}`;
      wallpaperModal.classList.add('hidden');
    });
  });

  btnInchatSearch.addEventListener('click', () => inchatSearchBar.classList.toggle('hidden'));
  closeInchatSearch.addEventListener('click', () => {
    inchatSearchBar.classList.add('hidden');
    inchatSearchInput.value = '';
    filterInchatMessages('');
  });

  inchatSearchInput.addEventListener('input', () => {
    filterInchatMessages(inchatSearchInput.value.trim().toLowerCase());
  });

  function filterInchatMessages(query) {
    document.querySelectorAll('.msg-wrapper').forEach(msgEl => {
      const text = msgEl.textContent.toLowerCase();
      if (!query || text.includes(query)) {
        msgEl.style.display = 'flex';
      } else {
        msgEl.style.display = 'none';
      }
    });
  }

  messageInput.addEventListener('input', () => {
    const hasText = messageInput.value.trim().length > 0;
    if (hasText) {
      sendBtn.classList.remove('hidden');
      voiceBtn.classList.add('hidden');
    } else {
      sendBtn.classList.add('hidden');
      voiceBtn.classList.remove('hidden');
    }

    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';

    if (socket) {
      socket.emit('typing:start', { roomId: currentRoomId });
      clearTimeout(typingTimeout);
      typingTimeout = setTimeout(() => {
        socket.emit('typing:stop', { roomId: currentRoomId });
      }, 1500);
    }
  });

  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendTextMessage();
    }
  });

  sendBtn.addEventListener('click', sendTextMessage);

  function sendTextMessage() {
    const text = messageInput.value.trim();
    if (!text || !socket) return;

    socket.emit('message:send', {
      roomId: currentRoomId,
      text: text,
      type: 'text',
      replyTo: activeReplyMsg
    });

    messageInput.value = '';
    messageInput.style.height = 'auto';
    sendBtn.classList.add('hidden');
    voiceBtn.classList.remove('hidden');
    
    if (activeReplyMsg) {
      activeReplyMsg = null;
      replyBanner.classList.add('hidden');
    }
  }

  function sendSticker(url) {
    if (!socket) return;
    socket.emit('message:send', {
      roomId: currentRoomId,
      type: 'sticker',
      fileUrl: url,
      replyTo: activeReplyMsg
    });
    emojiPopup.classList.add('hidden');
  }

  function sendGif(url) {
    if (!socket) return;
    socket.emit('message:send', {
      roomId: currentRoomId,
      type: 'gif',
      fileUrl: url,
      replyTo: activeReplyMsg
    });
    emojiPopup.classList.add('hidden');
  }

  voiceBtn.addEventListener('click', async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert('Запись аудио не поддерживается вашим браузером');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream);
      audioChunks = [];

      mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        const formData = new FormData();
        formData.append('file', audioBlob, 'voice.webm');

        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Bypass-Tunnel-Reminder': 'true' },
          body: formData
        });
        const data = await res.json();

        if (data.fileUrl && socket) {
          socket.emit('message:send', {
            roomId: currentRoomId,
            type: 'voice',
            fileUrl: data.fileUrl,
            replyTo: activeReplyMsg
          });
        }
      };

      mediaRecorder.start();
      voiceRecordingUI.classList.remove('hidden');
      recordSeconds = 0;
      voiceTimerEl.textContent = '00:00';
      recordingInterval = setInterval(() => {
        recordSeconds++;
        const mins = String(Math.floor(recordSeconds / 60)).padStart(2, '0');
        const secs = String(recordSeconds % 60).padStart(2, '0');
        voiceTimerEl.textContent = `${mins}:${secs}`;
      }, 1000);

    } catch (err) {
      console.error('Microphone access error:', err);
      alert('Не удалось получить доступ к микрофону!');
    }
  });

  cancelVoiceBtn.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      clearInterval(recordingInterval);
      voiceRecordingUI.classList.add('hidden');
    }
  });

  attachBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Bypass-Tunnel-Reminder': 'true' },
        body: formData
      });
      const data = await res.json();

      if (data.fileUrl && socket) {
        socket.emit('message:send', {
          roomId: currentRoomId,
          type: data.fileType,
          fileUrl: data.fileUrl,
          fileName: data.fileName,
          fileSize: data.fileSize,
          replyTo: activeReplyMsg
        });
      }
    } catch (err) {
      console.error('File upload error:', err);
    }
  });

  function renderStickersAndGifs() {
    stickersGrid.innerHTML = '';
    stickerPack.forEach(stk => {
      const img = document.createElement('img');
      img.src = stk.url;
      img.className = 'sticker-item';
      img.onclick = () => sendSticker(stk.url);
      stickersGrid.appendChild(img);
    });

    gifsGrid.innerHTML = '';
    gifPack.forEach(gif => {
      const img = document.createElement('img');
      img.src = gif.url;
      img.className = 'gif-item';
      img.onclick = () => sendGif(gif.url);
      gifsGrid.appendChild(img);
    });
  }

  const tabBtns = document.querySelectorAll('.popup-tabs .tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));

      btn.classList.add('active');
      const targetTab = document.getElementById(btn.getAttribute('data-tab'));
      if (targetTab) targetTab.classList.add('active');
    });
  });

  emojiPickerBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    emojiPopup.classList.toggle('hidden');
  });

  emojiPopup.querySelectorAll('.emoji-grid span').forEach(span => {
    span.addEventListener('click', () => {
      messageInput.value += span.textContent;
      messageInput.dispatchEvent(new Event('input'));
      emojiPopup.classList.add('hidden');
    });
  });

  document.addEventListener('click', (e) => {
    if (!emojiPopup.contains(e.target) && e.target !== emojiPickerBtn) {
      emojiPopup.classList.add('hidden');
    }
  });

  themeToggleBtn.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    themeToggleBtn.innerHTML = newTheme === 'dark' ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
  });

  async function openShareModal() {
    try {
      const res = await fetch('/api/info', {
        headers: { 'Bypass-Tunnel-Reminder': 'true' }
      });
      const info = await res.json();
      
      let finalUrl = 'https://my-telegram-messenger-v1.loca.lt';
      if (currentRoomId !== 'general') {
        finalUrl += `/?chat=${currentRoomId}`;
      }

      shareUrlInput.value = finalUrl;

      if (info.publicIp) {
        passcodeVal.textContent = info.publicIp;
        passcodeBox.classList.remove('hidden');
      }
    } catch (e) {
      shareUrlInput.value = window.location.href;
    }
    shareModal.classList.remove('hidden');
  }

  shareLinkBtn.addEventListener('click', openShareModal);
  headerShareBtn.addEventListener('click', openShareModal);
  closeShareModal.addEventListener('click', () => shareModal.classList.add('hidden'));

  copyShareBtn.addEventListener('click', () => {
    shareUrlInput.select();
    document.execCommand('copy');
    copyShareBtn.innerHTML = '<i class="fa-solid fa-check"></i> Скопировано!';
    setTimeout(() => {
      copyShareBtn.innerHTML = '<i class="fa-solid fa-copy"></i> Копировать';
    }, 2000);
  });

  function playNotificationSound() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch (e) {}
  }

  function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  function isImageFile(name) {
    if (!name) return false;
    return /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(name);
  }

  renderStickersAndGifs();
  initUserSession();
});
